# Devis Express — projet Next.js

## Démarrage

1. `npm install`
2. Copie `.env.example` en `.env.local` et remplis chaque clé (voir ci-dessous où les trouver)
3. Dans Supabase, ouvre l'éditeur SQL et exécute le contenu de `supabase/schema.sql`
4. Dans Stripe, crée 3 produits récurrents (2€, 5€, 10€/mois) et colle leurs `price_id`
   dans `.env.local`
5. `npm run dev` → http://localhost:3000

## Où trouver chaque clé

- **Supabase** : supabase.com → nouveau projet → Réglages → API (URL, anon key, service role key)
- **Stripe** : dashboard.stripe.com → Développeurs → Clés API (clé secrète + clé publique) ;
  le `STRIPE_WEBHOOK_SECRET` apparaît quand tu crées le endpoint webhook (voir plus bas)
- **Anthropic** : console.anthropic.com → API Keys
- **Resend** : resend.com → API Keys

## Configurer le webhook Stripe

En local, installe la Stripe CLI puis lance :
```
stripe listen --forward-to localhost:3000/api/webhooks/stripe
```
Elle t'affiche le `STRIPE_WEBHOOK_SECRET` à mettre dans `.env.local`.

En production (après déploiement sur Vercel), crée le endpoint dans le dashboard Stripe
avec l'URL `https://ton-domaine.fr/api/webhooks/stripe`, et copie le secret généré.

## Déploiement

```
npx vercel
```
Puis renseigne toutes les variables de `.env.local` dans Vercel → Réglages → Environment Variables.

## Ce qui est déjà branché

- Inscription / connexion réelles (Supabase Auth)
- Paiement réel (Stripe Checkout, carte + Apple Pay + Google Pay activés automatiquement)
- Webhook qui active l'abonnement et envoie les emails de bienvenue
- Dashboard protégé (middleware) qui lit les vraies données Supabase
- Génération de devis avec l'API Anthropic si `ANTHROPIC_API_KEY` est renseignée
  (sinon, le texte saisi est utilisé tel quel)

## Ce qu'il reste à faire

- Export PDF serveur (`@react-pdf/renderer`) — pas encore implémenté dans ce scaffold
- Signature électronique persistée en base
- Templates d'emails plus soignés (react-email)
- Page listant/filtrant tous les devis, formulaire de création dans /dashboard/devis
