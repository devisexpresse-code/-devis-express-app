create table profiles (
  id uuid references auth.users on delete cascade primary key,
  full_name text,
  company_name text,
  created_at timestamptz default now()
);

create table subscriptions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references profiles(id) on delete cascade not null,
  stripe_customer_id text,
  stripe_subscription_id text,
  plan text check (plan in ('starter', 'pro', 'business')) not null,
  status text check (status in ('active', 'trialing', 'past_due', 'canceled')) not null default 'active',
  current_period_end timestamptz,
  created_at timestamptz default now()
);

create table clients (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references profiles(id) on delete cascade not null,
  name text not null,
  email text,
  created_at timestamptz default now()
);

create table devis (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references profiles(id) on delete cascade not null,
  client_id uuid references clients(id),
  client_name text not null,
  description text,
  montant_ht numeric not null,
  tva_pct numeric not null default 20,
  delai text,
  score_acceptation int,
  statut text check (statut in ('brouillon', 'envoye', 'accepte', 'refuse')) default 'brouillon',
  pdf_url text,
  signed_at timestamptz,
  created_at timestamptz default now()
);

create table notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references profiles(id) on delete cascade not null,
  type text check (type in ('devis_cree', 'devis_telecharge', 'paiement_recu', 'abonnement_expire')) not null,
  message text not null,
  read boolean default false,
  created_at timestamptz default now()
);

alter table profiles enable row level security;
alter table subscriptions enable row level security;
alter table clients enable row level security;
alter table devis enable row level security;
alter table notifications enable row level security;

create policy "Users manage their own profile" on profiles for all using (auth.uid() = id);
create policy "Users manage their own subscriptions" on subscriptions for all using (auth.uid() = user_id);
create policy "Users manage their own clients" on clients for all using (auth.uid() = user_id);
create policy "Users manage their own devis" on devis for all using (auth.uid() = user_id);
create policy "Users manage their own notifications" on notifications for all using (auth.uid() = user_id);

-- Crée automatiquement un profil à chaque inscription
create function public.handle_new_user()
returns trigger as $$
begin
  insert into public.profiles (id) values (new.id);
  return new;
end;
$$ language plpgsql security definer;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();
