import Link from 'next/link';

const plans = [
  { name: 'Starter', price: '2€', feats: ['20 devis par mois', 'PDF standard', 'Support email'] },
  { name: 'Business', price: '10€', featured: true, feats: ['Devis illimités', 'Toutes les fonctionnalités', 'Support prioritaire', 'Accès aux nouveautés'] },
  { name: 'Pro', price: '5€', feats: ['200 devis par mois', 'PDF premium', 'Historique complet', 'Priorité support'] },
];

export default function Home() {
  return (
    <main className="max-w-6xl mx-auto px-6">
      <nav className="flex items-center justify-between py-6">
        <span className="font-display font-semibold">Devis Express</span>
        <div className="flex gap-3">
          <Link href="/login" className="glass px-4 py-2 rounded-xl text-sm">Connexion</Link>
          <Link href="/signup" className="btn-primary px-4 py-2 rounded-xl text-sm font-semibold">Créer un compte</Link>
        </div>
      </nav>

      <section className="py-24 text-center">
        <h1 className="font-display text-5xl font-semibold mb-6">
          Bienvenue sur <span className="gradient-text">Devis Express</span>
        </h1>
        <p className="text-inkDim max-w-xl mx-auto mb-8">
          Créez des devis professionnels en moins de 30 secondes grâce à l'intelligence artificielle.
        </p>
        <Link href="/signup" className="btn-primary inline-block px-6 py-3 rounded-xl font-semibold">
          Créer un compte
        </Link>
      </section>

      <section id="tarifs" className="py-16">
        <h2 className="font-display text-3xl font-semibold text-center mb-10">Nos formules</h2>
        <div className="grid md:grid-cols-3 gap-6">
          {plans.map((p) => (
            <div
              key={p.name}
              className={`glass rounded-2xl p-8 ${p.featured ? 'border-gold/50 scale-105' : ''}`}
            >
              <div className="text-inkDim text-xs uppercase tracking-wide mb-3">{p.name}</div>
              <div className="font-display text-4xl font-bold mb-4">{p.price}<span className="text-sm text-inkFaint">/mois</span></div>
              <ul className="space-y-2 mb-6 text-sm text-inkDim">
                {p.feats.map((f) => <li key={f}>✓ {f}</li>)}
              </ul>
              <Link
                href={`/signup?plan=${p.name.toLowerCase()}`}
                className={`block text-center py-2 rounded-xl text-sm font-semibold ${p.featured ? 'btn-primary' : 'glass'}`}
              >
                Choisir {p.name}
              </Link>
            </div>
          ))}
        </div>
      </section>
    </main>
  );
}
