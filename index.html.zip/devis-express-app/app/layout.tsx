import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'Devis Express — Devis professionnels par IA',
  description: "Générez des devis professionnels en 30 secondes grâce à l'IA. Une solution LuminaWeb.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="fr">
      <body>{children}</body>
    </html>
  );
}
