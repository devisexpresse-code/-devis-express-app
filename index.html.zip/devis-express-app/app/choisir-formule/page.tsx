'use client';
import { useState } from 'react';
import { useSearchParams } from 'next/navigation';

const plans = [
  { id: 'starter', name: 'Starter', price: '2€' },
  { id: 'business', name: 'Business', price: '10€', featured: true },
  { id: 'pro', name: 'Pro', price: '5€' },
];

export default function ChoisirFormulePage() {
  const searchParams = useSearchParams();
  const preselected = searchParams.get('plan');
  const [loadingPlan, setLoadingPlan] = useState<string | null>(null);

  async function choosePlan(planId: string) {
    setLoadingPlan(planId);
    const res = await fetch('/api/checkout', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ plan: planId }),
    });
    const data = await res.json();
    if (data.url) window.location.href = data.url;
    else setLoadingPlan(null);
  }

  return (
    <main className="max-w-3xl mx-auto px-6 py-24 text-center">
      <h1 className="font-display text-3xl font-semibold mb-3">Choisissez votre formule</h1>
      <p className="text-inkDim mb-10">Un abonnement actif est nécessaire pour accéder au tableau de bord.</p>
      <div className="grid md:grid-cols-3 gap-6">
        {plans.map((p) => (
          <button
            key={p.id}
            onClick={() => choosePlan(p.id)}
            disabled={loadingPlan !== null}
            className={`glass rounded-2xl p-8 text-left ${p.featured ? 'border-gold/50' : ''} ${preselected === p.id ? 'ring-2 ring-violet' : ''}`}
          >
            <div className="text-inkDim text-xs uppercase mb-2">{p.name}</div>
            <div className="font-display text-3xl font-bold mb-4">{p.price}<span className="text-sm text-inkFaint">/mois</span></div>
            <span className="btn-primary block text-center py-2 rounded-xl text-sm font-semibold">
              {loadingPlan === p.id ? 'Redirection…' : `Choisir ${p.name}`}
            </span>
          </button>
        ))}
      </div>
    </main>
  );
}
