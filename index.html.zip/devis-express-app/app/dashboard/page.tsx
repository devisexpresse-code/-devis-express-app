import { createServerComponentClient } from '@/lib/supabase/server';

export default async function DashboardPage() {
  const supabase = createServerComponentClient();
  const { data: { user } } = await supabase.auth.getUser();

  const { data: devis } = await supabase
    .from('devis')
    .select('*')
    .eq('user_id', user?.id)
    .order('created_at', { ascending: false })
    .limit(10);

  const total = devis?.length || 0;
  const acceptes = devis?.filter((d) => d.statut === 'accepte').length || 0;
  const ca = devis?.reduce((sum, d) => sum + Number(d.montant_ht || 0), 0) || 0;

  return (
    <main className="max-w-5xl mx-auto px-6 py-16">
      <h1 className="font-display text-2xl font-semibold mb-8">Tableau de bord</h1>
      <div className="grid md:grid-cols-3 gap-4 mb-10">
        <div className="glass rounded-2xl p-6">
          <div className="font-display text-2xl font-bold">{ca.toLocaleString('fr-FR')} €</div>
          <div className="text-xs text-inkFaint mt-1">Chiffre d'affaires estimé</div>
        </div>
        <div className="glass rounded-2xl p-6">
          <div className="font-display text-2xl font-bold">{total}</div>
          <div className="text-xs text-inkFaint mt-1">Devis créés</div>
        </div>
        <div className="glass rounded-2xl p-6">
          <div className="font-display text-2xl font-bold">{total ? Math.round((acceptes / total) * 100) : 0}%</div>
          <div className="text-xs text-inkFaint mt-1">Taux d'acceptation</div>
        </div>
      </div>

      <div className="glass rounded-2xl p-6">
        <h2 className="font-semibold mb-4">Derniers devis</h2>
        {(!devis || devis.length === 0) && (
          <p className="text-inkDim text-sm">Aucun devis pour le moment.</p>
        )}
        <div className="space-y-2">
          {devis?.map((d) => (
            <div key={d.id} className="flex justify-between text-sm py-2 border-b border-white/5">
              <span>{d.client_name}</span>
              <span className="text-inkFaint">{d.statut}</span>
            </div>
          ))}
        </div>
      </div>
    </main>
  );
}
