import { NextRequest, NextResponse } from 'next/server';
import { createServerComponentClient } from '@/lib/supabase/server';

// Génère le texte du devis via l'API Anthropic, puis l'enregistre en base.
export async function POST(req: NextRequest) {
  const { clientName, description, prix, tvaPct, delai } = await req.json();

  const supabase = createServerComponentClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: 'Non authentifié' }, { status: 401 });

  let redaction = description;
  if (process.env.ANTHROPIC_API_KEY) {
    const aiRes = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': process.env.ANTHROPIC_API_KEY,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-6',
        max_tokens: 400,
        messages: [{
          role: 'user',
          content: `Rédige la description détaillée d'un devis professionnel en français pour : ${description}. Client : ${clientName}. Délai : ${delai}. Reste concis (3-4 phrases), ton professionnel.`,
        }],
      }),
    });
    const aiData = await aiRes.json();
    redaction = aiData?.content?.[0]?.text || description;
  }

  const montantTtc = prix * (1 + tvaPct / 100);
  const score = Math.max(40, Math.min(95, 65 + (prix < 1500 ? 10 : -5)));

  const { data, error } = await supabase.from('devis').insert({
    user_id: user.id,
    client_name: clientName,
    description: redaction,
    montant_ht: prix,
    tva_pct: tvaPct,
    delai,
    score_acceptation: score,
    statut: 'brouillon',
  }).select().single();

  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  return NextResponse.json({ devis: data, montant_ttc: montantTtc });
}
