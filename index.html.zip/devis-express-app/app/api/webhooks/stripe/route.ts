import { NextRequest, NextResponse } from 'next/server';
import { stripe } from '@/lib/stripe';
import { createServiceClient } from '@/lib/supabase/server';
import { Resend } from 'resend';

const resend = new Resend(process.env.RESEND_API_KEY);

export async function POST(req: NextRequest) {
  const body = await req.text();
  const sig = req.headers.get('stripe-signature')!;

  let event;
  try {
    event = stripe.webhooks.constructEvent(body, sig, process.env.STRIPE_WEBHOOK_SECRET!);
  } catch (err) {
    return NextResponse.json({ error: 'Signature invalide' }, { status: 400 });
  }

  const supabase = createServiceClient();

  if (event.type === 'checkout.session.completed') {
    const session = event.data.object as any;
    const userId = session.client_reference_id;
    const plan = session.metadata?.plan;

    await supabase.from('subscriptions').insert({
      user_id: userId,
      stripe_customer_id: session.customer,
      stripe_subscription_id: session.subscription,
      plan,
      status: 'active',
    });

    if (session.customer_email) {
      await resend.emails.send({
        from: 'Devis Express <onboarding@resend.dev>',
        to: session.customer_email,
        subject: 'Bienvenue sur Devis Express 🎉',
        html: `<p>Merci pour votre inscription à la formule ${plan}. Votre tableau de bord est prêt.</p>`,
      });
      await resend.emails.send({
        from: 'Devis Express <onboarding@resend.dev>',
        to: process.env.ADMIN_EMAIL!,
        subject: 'Nouvel abonné Devis Express',
        html: `<p>Nouvel abonnement : ${session.customer_email} — formule ${plan}.</p>`,
      });
    }
  }

  if (event.type === 'customer.subscription.updated') {
    const sub = event.data.object as any;
    await supabase.from('subscriptions')
      .update({ status: sub.status })
      .eq('stripe_subscription_id', sub.id);
  }

  if (event.type === 'customer.subscription.deleted') {
    const sub = event.data.object as any;
    await supabase.from('subscriptions')
      .update({ status: 'canceled' })
      .eq('stripe_subscription_id', sub.id);
  }

  return NextResponse.json({ received: true });
}
