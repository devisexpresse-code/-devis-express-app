import type { Config } from 'tailwindcss';

const config: Config = {
  content: ['./app/**/*.{ts,tsx}', './components/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        bg: '#06070f',
        ink: '#eef0fb',
        inkDim: '#9aa0c2',
        inkFaint: '#5c6182',
        violet: '#6d5dfc',
        cyan: '#22d3ee',
        gold: '#f5c451',
      },
      fontFamily: {
        display: ['"Space Grotesk"', 'Inter', 'sans-serif'],
        body: ['Inter', 'system-ui', 'sans-serif'],
      },
      borderRadius: { xl2: '20px' },
    },
  },
  plugins: [],
};
export default config;
